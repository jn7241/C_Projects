#include <stdio.h>
int main(void)
/*Algorithm which calculates average 
seal population in an array of 
1000 seal population data points.

CLARIFICATIONS:
1.TO RUN THE CODE PROPERLY, 
YOU MUST HAVE eldata.txt AND THE EXECUTABLE
OF THE SOURCE CODE IN THE SAME FILE LOCATION
DUE TO fopen, fscanf. 
2. THE SEAL DATA ARRAY HAS 1000 
DATA PIECES REGARDING THE POPULATION 
OF ELEPHANT SEALS, FOUND BY 
LOOKING AT EACH ELEMENT, AND 
IF THERE'S NO EMPTY SPACE,
ADD TO A VARIABLE NAMED length 
3. THE ARRAY WHICH IS USED TO STORE 
THE ELEPHANT SEAL DATA, CAN HOLD UP 
TO 10000 ELEMENTS
4. AVERAGE IS CALCULATED BY THE DIVISION OF 
sum AND length. 
5. CODE WORKS BECAUSE OF scanf(). 
IT IS ONLY LOOKING AT NUMBERS, EVEN THOUGH 
EACH NUMBER HAS AN EMPTY SPACE BETWEEN.
*/

{
	float elphno[10000]; //elephant seal data array
	int i = 0;   
	FILE *file; //file pointer to eldata.txt
	float length = 0;
	float sum, AVERAGE; 
	
	
	if (file = fopen("eldata.txt", "r"))
	{
		while(fscanf(file, "%f", &elphno[i]) != EOF)
		{
			i++;
		}
		
		/*while loop puts each integer value of *file in 
		elphno array, which holds all numbers
		from eldata.txt.
		i points current location in array. 
		starts at int i = 0, and gets incremented each
		loop.
		*/
		
		fclose(file);
		elphno[i] = '\n'; 
		
		/*By assigning new line to ith element, next for loop ends
		properly.
		*/
		printf("Below are all the elephant seal data: \n");
		for (i=0; elphno[i] != '\n'; i++){
		// for loop works looks at cases where there's no empty space
		printf("%f\n", elphno[i]); 
		length++;
		//this prints array contents
	
		}

	
		
		
		
	
		
				
		printf("\nThe amount of seal population data being looked at is: %f", length);
		// length <=> the amount of seal population data
		for (i=0; i<= 1000; i++)
		//1000th element last element needed for sum
			sum = sum + elphno[i];
		
		AVERAGE = sum / length; //sum divided by number of seal population data
		printf("\nThe average elephant seal population is %f", AVERAGE);
		
	}


return 0;
}